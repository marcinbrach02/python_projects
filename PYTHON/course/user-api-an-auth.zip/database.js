var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('./data/db');

db.serialize(function () {
    
    db.run('DROP TABLE IF EXISTS user;');

    let sql = `CREATE TABLE user(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nickname            TEXT      NOT NULL,
                    email               TEXT      NOT NULL,
                    password            TEXT      NOT NULL
                );`;

    db.run(sql);

    var stmt = db.prepare("INSERT INTO user (nickname, email, password) VALUES (?, ?, ?)");
    stmt.run(['kmalinowski', 'km@aa.pl', 'a']);
    stmt.run(['amoroz', 'am@aa.pl', 'b']);

    stmt.finalize();


    db.each("SELECT * FROM user", function (err, row) {
        console.log(row);
    });
});

db.close();