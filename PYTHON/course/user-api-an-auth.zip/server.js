var express = require('express'),
        app = express(),
        port = process.env.PORT || 3000,
        bodyParser = require('body-parser');

var session = require('express-session');

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

var routes = require('./src/routes/userListRoutes');

app.use(session({
    secret: 'altkom akademia',
    resave: false,
    saveUninitialized: true
}));

app.all('/*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', 'http://localhost:4200');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

routes(app);

app.listen(port);

console.log('User list RESTful API server started on: ' + port);