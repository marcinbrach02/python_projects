'use strict';
module.exports = function (app) {
    var userList = require('../controllers/userListController');

    // todoList Routes
    app.route('/user')
            .get(userList.getAll)
            .post(userList.create);


    app.route('/user/:userId')
            .get(userList.get)
            .put(userList.update)
            .delete(userList.delete);
    
    app.route('/user/email/:email').get(userList.emailExists);
    
    app.route('/user/auth').post(userList.auth);
    
    app.route('/session').get(userList.session);
    
    app.route('/destroy').get(userList.destroy);
};
