'use strict';

var userModel = require('../models/userListModel');

exports.getAll = (req, res) => {
    userModel.getAll( users => res.json(users) );
};

exports.create = (req, res) => {
    userModel.add(req.body, row => { res.json(row) }, () => res.sendStatus(400));
};

exports.get = (req, res) => {
    userModel.get(req.params.userId, user => res.json(user), () => res.sendStatus(404));
};

exports.update = (req, res) => {
    userModel.get(req.params.userId, () => {
        
        userModel.edit(req.body, req.params.userId, () => res.json(true), () => res.sendStatus(400));
        
    }, () => res.sendStatus(404));
};

exports.delete = (req, res) => {
    userModel.get(req.params.userId, () => {
        
        userModel.delete(req.params.userId, () => res.json(true), () => res.sendStatus(400));
        
    }, () => res.sendStatus(404));
};

exports.emailExists = (req, res) => {
    userModel.emailexists(req.params.email, () => res.json({exists: true}), () => res.json({exists: false}));
}

exports.auth = (req, res) => {
    userModel.auth(req.body.nickname, req.body.password, user => {
        req.session.user = user;
        res.json({success: true});
    }, () => res.sendStatus(403));
};

exports.session = (req, res) => {
    if (req.session.user) {
        res.json({login: true})
    } else {
        res.sendStatus(401);
    }
};

exports.destroy = (req, res) => {
    if (req.session.user) {
        delete req.session.user;
    }
    res.json({success: true});
};
