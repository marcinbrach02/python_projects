'use strict';

var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('./data/db');

exports.getAll = (callback) => {
    db.all("SELECT * FROM user", function (err, rows) {
        callback(rows);
    });
};

exports.get = (id, callback, emptycallback) => {
    db.each('SELECT * FROM user WHERE id = ?', [id], (err, row) => {
        callback(row);
    }, (err, rows) => {
        if (rows == 0) {
            emptycallback();
        }
    });
};

exports.emailexists = (email, exists, noexists) => {
    db.each('SELECT * FROM user WHERE email = ?', [email], (err, row) => {
        exists();
    }, (err, rows) => {
        if (rows == 0) {
            noexists()
        }
    });
};

exports.add = (row, callback, errorcallback) => {
    var stmt = db.prepare("INSERT INTO user (nickname, email, password) VALUES (?, ?, ?)");

    stmt.run([row.nickname, row.email, row.password], function (err) {
        if (err) {
            errorcallback();
        } else {
            db.each('SELECT * FROM user WHERE id = ?', [this.lastID], (err, row) => {
                callback(row);
            });
        }
    });

};

exports.edit = (row, id, callback, errorcalback) => {
    let params = [];
    let keys = [];

    for (let key in row) {
        keys.push(`${key} = ?`);
        params.push(row[key]);
    }

    params.push(id);

    const stmt = db.prepare(`UPDATE user SET ${keys.join(', ')} WHERE id = ?`, err => {
        if (err) {
            errorcalback();
        }
    });

    stmt.run(params, err => {
        if (err) {
            errorcalback();
        } else {
            callback();
        }
    });
};

exports.delete = (id, callback, errorcalback) => {
    const stmt = db.prepare(`DELETE FROM user WHERE id = ?`, err => {
        if (err) {
            errorcalback();
        }
    });

    stmt.run([id], err => {
        if (err) {
            errorcalback();
        } else {
            callback();
        }
    });
};

exports.auth = (nickname, password, callback, emptycallback) => {
    db.each('SELECT * FROM user WHERE nickname = ? AND password = ?', [nickname, password], (err, row) => {
        callback(row);
    }, (err, rows) => {
        if (rows == 0) {
            emptycallback();
        }
    });
};
